# SA KHELCOM — prototype Android

Application de transport Dakar inspirée du parcours demandé :
- Client : départ, destination, GPS, Éco / Confort / Confort+, estimation, espèces/Wave, commande.
- Chauffeur : en ligne/hors ligne, courses, accepter/refuser, gains, inscription.
- Admin : statistiques et tarifs.
- Identité : SA KHELCOM — « Votre trajet, notre priorité ».

## Construire l'APK avec GitHub
1. Créez un dépôt GitHub et envoyez tous les fichiers de ce projet.
2. Le workflow `.github/workflows/build-apk.yml` se lance automatiquement.
3. Dans GitHub : Actions → Build SA-KHELCOM APK → attendre la fin.
4. Ouvrez le run terminé → Artifacts → `SA-KHELCOM-debug-apk` → récupérez `app-debug.apk`.

## Important
Ce prototype fonctionne hors ligne dans l'application Android. Le GPS Android est demandé, mais le trajet réel, la base de données, les comptes, les notifications, le matching chauffeur-client et le paiement Wave réel doivent encore être connectés à un backend avant une mise en production.
Le lien Wave réel n'est volontairement pas inventé : ajoutez le lien marchand officiel de SA KHELCOM dans le code avant le lancement.
