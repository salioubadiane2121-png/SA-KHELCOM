# SA KHELCOM - no custom ProGuard rules for prototype
